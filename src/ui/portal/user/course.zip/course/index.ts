export { CourseAssessmentsView } from './CourseAssessmentsView';
export { CourseOverviewView } from './CourseOverviewView';
export { CourseNavigation } from './components/CourseNavigation';
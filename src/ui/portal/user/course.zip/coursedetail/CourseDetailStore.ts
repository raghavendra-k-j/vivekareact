export interface CourseDetailStoreProps {
    // Empty parameters for scaffolding
}

export class CourseDetailStore {
    constructor(_props: CourseDetailStoreProps) {
        // Empty constructor for scaffolding
    }
}
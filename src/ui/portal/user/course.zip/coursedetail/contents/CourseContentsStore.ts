export interface CourseContentsStoreProps {
    // Empty parameters for scaffolding
}

export class CourseContentsStore {
    constructor(_props: CourseContentsStoreProps) {
        // Empty constructor for scaffolding
    }
}
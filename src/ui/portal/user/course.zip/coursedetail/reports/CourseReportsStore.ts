export interface CourseReportsStoreProps {
    // Empty parameters for scaffolding
}

export class CourseReportsStore {
    constructor(_props: CourseReportsStoreProps) {
        // Empty constructor for scaffolding
    }
}
export class AiGenPageStore {

    

}
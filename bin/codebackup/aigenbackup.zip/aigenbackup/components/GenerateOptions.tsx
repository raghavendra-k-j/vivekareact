import { Card, CardBody, CardHeader } from "~/ui/components/card";

export default function InputSourceStepView() {
    return (<Card className="" shadow="sm" radius="sm">
        <CardHeader>
            <h2 className="text-lg font-semibold">Input Source</h2>
        </CardHeader>
        <CardBody>

        </CardBody>
    </Card>);
}